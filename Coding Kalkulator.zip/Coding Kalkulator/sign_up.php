<html>
<body>
<style>
body{
background-color:lightpink;
}
</style>
<center><img src="hi.gif" alt="login"  style="width:700px;height:200;"/></center>
<body bgcolor="cyan">
<form action="signupprocess.php" method="post">
<h1><center> Daftar </center></h1>
<center>
<table width="400" border="1">
<tr>
<th scope="col">Username:</th>
<th scope="col"><div align="left">
<input type="text" name="username" size="20"/>
</div>
</th>
</tr>
<tr>
<th scope="col">Password:</th>
<th scope="col"><div align="left">
<input type="password" name="password"size="20"/>
</div>
</th>
</tr>
<table>
<div class="clearfix">
      <input type="reset"  class="resetbtn"></input>
      <button type="submit" class="signupbtn">Sign Up</button>
    </div>
<br>
</div>
</form>
</center>
</html>
<html>
<style>
body{
  background-color:lightpink;
}
</style><center>
<form id="form" name="form" method="post" action="prosinsert.php">
<table width="400" border="1">
<tr>
<th scope="col">Jawapan:</th>
<th scope="col"><div align="left">
<input type="text" name="jawapan" value="" size="30"/>
</div>
</th>
</tr>
<tr>
<th scope="col">Catatan:</th>
<th scope="col"><div align="left">
<input type="text" name="catatan" value="" size="30"/>
</div>
</th>
</tr>
</table>
<br>
<center><button type="submit" value="submit">Submit</button>
<button type="reset" value="reset"> Reset </button>
</div>
</th>
</tr>
</center>
</body>
</html>
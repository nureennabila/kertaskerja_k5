<!DOCTYPE html>
<html>
<style>
body{
  background-color:lightpink;
}
</style><center>
<img src="cal.png" width="300" height="300">
<form id="form" name="form" method="post" action="pros_insert.php">
<table width="400" border="1">
<tr>
<th scope="col">Nama:</th>
<th scope="col"><div align="left">
<input type="text" name="nama" value="" size="20"/>
</div>
</th>
</tr>
<tr>
<th scope="col">Nombor Kad Pengenalan:(Tanpa-)</th>
<th scope="col"><div align="left">
<input type="text" name="noic" value="" size="20"/>
</div>
</th>
</tr>
<tr>
<th scope="col">Nombor Angka Giliran:</th>
<th scope="col"><div align="left">
<input type="text" name="noang" value="" size="20"/>
</div>
</th>
</tr>
</table>
<br>
<center><button type="submit" value="submit">Submit</button>
<button type="reset" value="reset"> Reset </button>
</div>
</th>
</tr>
</center>
</body>
</html>
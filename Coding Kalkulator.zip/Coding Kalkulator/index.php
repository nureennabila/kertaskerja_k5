<!DOCTYPE html>
<html>
<head>
<center><body bgcolor="pink">
<body>
	<center><img src="calculator.png" width="300": height="300";></center>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
div.scrollmenu {
    background-color: #ff4d88;
    overflow: auto;
    white-space: nowrap;
}

div.scrollmenu a {
    display: inline-block;
    color: black;
    text-align: center;
    padding: 16px;
    text-decoration: none;
}

div.scrollmenu a:hover {
    background-color: #ffccdc;
}
</style>
</head>
<body>
<h2>
<div class="scrollmenu">
  <a href="login.php">Sign In</a>
  <a href="sign_up.php">Sign Up</a>
  <a href="about.php">About Us</a>
</h2>
</div>


</body>
</html>

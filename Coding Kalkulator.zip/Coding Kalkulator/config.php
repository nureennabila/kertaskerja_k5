<?php
$query=mysql_connect("localhost","syareen","melati1718");
mysql_select_db("syareen",$query);
echo '';
?>

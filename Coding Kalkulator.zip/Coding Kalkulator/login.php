<html>
<body>

<style>
  body{
  background-color:lightpink;
}
</style>
<body bgcolor="cyan">
<form action="loginprocess.php" method="post">
<center><img src="login.png" alt="login"  style="width:250px;height:200;"/></center>
</style>
<h1><center> Sign In </center></h1>
<center>
<table width="400" border="1">
<tr>
<th scope="col">Username:</th>
<th scope="col"><div align="left">
<input type="text" name="username" size="50"/>
</div>
</th>
</tr>

<tr>
<th scope="col">Password:</th>
<th scope="col"<div align="left">
<input type="password" name="password"
size="10"/>
</div>
</th>
</tr>
</table>
<br>
<center><button type="submit" value="submit">Submit</button>
<button type="reset" value="reset"> Reset </button>
<br>
</div>
</form>
</center>
</html>
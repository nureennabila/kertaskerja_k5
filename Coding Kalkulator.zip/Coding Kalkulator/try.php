<html>
<head><title>KALKULATOR SYAREEN</title>
</head>
<body>
<script>
function nureen(){
	document.getElementById('kalkulator').src='1.jpg';
}
function syaza(){
	document.getElementById('kalkulator').src='2.jpg';
}
</script>
<style>
body{
  background-color:lightpink;
}
  table,tr,th,td{
  padding:10px;}
  tr,th,td
  {
	  border:1px solid red;
  }
  th{
  background-color:#ff6699;}
  </style>
 

  <body>
  <center>
  <table>
  <h2>About Us</h2>
  <tr><h3>
<td><img id="java" src="1.jpg" style="width:250px"></td>
 <td>NAMA : NUREEN NABILA BINTI MUHAMMAD ALI<br>
  UMUR : 17 TAHUN<br>
 TEMPAT TINGGAL : PASIR GUDANG JOHOR<br>
 TARIKH LAHIR : 12/8/2001</h3></td>
<tr><h3>   
<td><img id="java" src="2.jpg" style="width:250px"><br>
<td>NAMA : NUR SYAZA MD HASHIM<br>
UMUR : 17 TAHUN<br>
TEMPAT TINGGAL : KEMPAS JOHOR BAHRU<br>
TARIKH LAHIR : 30/7/2001</h3></td>
</p>
 </center>